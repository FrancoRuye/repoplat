// socket-io-app.js
var socket = io('http://tu-servidor-de-socket.io');

socket.on('mensaje', function(data) {
    console.log('Mensaje recibido:', data);
});