<?php


function enqueue_all_files_in_folder($folder_path, $file_type, $handle_prefix) {
    $files = glob("$folder_path/*.$file_type");

    if ($files) {
        foreach ($files as $file) {
            $file_name = basename($file, ".$file_type");
            $handle = $handle_prefix . $file_name;

            if ($file_type === 'css') {
                wp_enqueue_style($handle, get_template_directory_uri() . '/' . $folder_path . '/' . $file_name . '.' . $file_type);
            } elseif ($file_type === 'js') {
                wp_enqueue_script($handle, get_template_directory_uri() . '/' . $folder_path . '/' . $file_name . '.' . $file_type, array(), '', true);
            }
        }
    }
}

// Enlazar el archivo CSS en la carpeta 'sit3/Panel/assets/css'
enqueue_all_files_in_folder('<?php echo get_template_directory_uri(); ?>', 'css', 'sit3-style-');

// Enlazar todos los archivos JS en la carpeta 'sit3/js'
enqueue_all_files_in_folder('<?php echo get_template_directory_uri(); ?>', 'js', 'sit3-script-');

// functions.php
function enqueue_socket_io_script() {
    wp_enqueue_script('socket-io', get_template_directory_uri() . '/socket.io.js', array(), '1.0', true);
}

add_action('wp_enqueue_scripts', 'enqueue_socket_io_script');