// Inicializa Ably con tu clave de API
var ably = new Ably.Realtime('CpMl3Q.p9OuPg:4XA9ZL7soP5mzu2FGqlJ-jzwinmrrM9XIJb9HQLgyw4');

// Ahora puedes utilizar 'ably' para enviar y recibir mensajes en tiempo real
var channel = ably.channels.get('mi-canal');

// Ejemplo de suscripción a un evento en el canal
channel.subscribe('mi-evento', function(message) {
  console.log('Mensaje recibido:', message.data);
});

// Ejemplo de publicación de un mensaje en el canal
channel.publish('mi-evento', 'Hola, Ably!');